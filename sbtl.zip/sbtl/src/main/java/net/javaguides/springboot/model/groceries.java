package net.javaguides.springboot.model;

public class groceries {

}
